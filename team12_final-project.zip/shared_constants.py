#!/usr/bin/python
# CS 4404 final project
# Devon Coleman, Kyle McCormick, Christopher Navarro, William Van Rensselaer

ADDR_PREFIX = "10.4.12."
CLIENT_ADDR = ADDR_PREFIX + "1"
APP_ADDR = ADDR_PREFIX + "2"
WEB_SERVER_ADDR = ADDR_PREFIX + "3" 
HONEYPOT_ADDR = ADDR_PREFIX + "4"
APP_HONEYPOT_PORT = 44044
START_CLIENT_IP = 150
NUM_CLIENTS = 100

